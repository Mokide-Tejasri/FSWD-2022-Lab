const express = require('express');
const bodyparser=require("body-parser")
const mongoose = require('mongoose');
const bcrypt=require("bcrypt");
const {check, validationResult} = require('express-validator')
const user=require('./models/user');
const app = express();
const port = process.env.PORT || 80


mongoose.connect("mongodb://localhost:27017/users");
let db=mongoose.connection;
db.on("error",error=>console.log("error"))
db.once("open",open=>console.log("database connection sucess"))


app.set('view engine', 'pug');

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));


app.get('/Register',
    function(req,res){
      
    res.render('Register')
    })
    app.post('/Register',
    [
        check('username').not().isEmpty().isLength({min:5}).withMessage('User name must be 5 characters'),
        check('password').not().isEmpty().isLength({min:6}).withMessage('Password name must be 6 characters'),
        check('age').not().isEmpty().isInt().withMessage('age  must be integer'),
        check('mobile').not().isEmpty().isInt().isLength({min:10}).withMessage('mobile number must be number and 10 characters'),
        check('cpassword').custom((value,{req}) => (value === req.body.password)).withMessage("Confirm password not match with your password"),
        check('email').not().isEmpty().isEmail().normalizeEmail().withMessage("Enetr proper email"),
    ],
    
        function(req,res){
            
            const errors= validationResult(req);
            if(!errors.isEmpty())
            {
                return res.status(422).jsonp(errors.array());
            }
            else{
    
            //console.log(req.body.username)
            const newUser=new user();
            newUser.username=req.body.username;
    
            
            var salt=bcrypt.genSaltSync(10);
            var hash=bcrypt.hashSync(req.body.password,salt);
    
            newUser.password=hash;
    
            newUser.age=req.body.age;
            newUser.mobile=req.body.mobile;
    
            newUser.save(function(err,result){
    
                if(err){
    
                    console.log(err);
                }
                else{
                    console.log(result);
                    res.send("user registered sucess fully")
                }
                
            })
        
        }
    
        })
    


 app.listen(port,() => {console.log(`app is listening on http://localhost:${port}`)})